# License Detection > 2026-07-25 8:30am
https://universe.roboflow.com/luizs-workspace-ienqd/license-detection-9hd4c

Provided by a Roboflow user
License: CC BY 4.0

